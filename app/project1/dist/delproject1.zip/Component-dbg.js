sap.ui.define(["sap/fe/core/AppComponent"], function(AppComponent) {
    'use strict';

    return AppComponent.extend("del.project1.Component", {
        metadata: {
            manifest: "json"
        }
    });
});
